module.exports = {
  name: 'bug',
  async execute(message) {
    message.reply('To report a big please first see our Faq at https://docs.mcstatusbot.discord/faq or join our support server https://mcstatusbot.site/discord')
  }
}
