module.exports = {
  path: '/',
  run(shards, req, res) {
    return res.status(200).send()
  }
}
