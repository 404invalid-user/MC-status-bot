module.exports = {
  path: '/discord',
  run(shards, req, res) {
    return res.redirect('https://discord.com/invite/YzX5KdF4kq')
  }
}
