# MC-status documentation

[api documentation](https://docs.mcstatusbot.site/api)
[variables chart embed](https://docs.mcstatusbot.site/variables/chart)
[variables for notifications](https://docs.mcstatusbot.site/variables/notifications)
