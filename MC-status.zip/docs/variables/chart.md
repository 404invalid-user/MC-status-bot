# variables chart embed

### place these in the text section on your dashboard where you would like the value to show up

- [ip] - your Minecraft server ip.
- [ip-noport] - your Minecraft server ip without the port number.
- [name] - your discord servers name.
- [maxplayersonline] - the maximum amount of players that have ever been on your server.
- [minplayersonline] - the minimum amount of players that have ever been on your server.
- [uptime] - your minecraft servers uptime in minutes.
- [downtime] - your minecraft servers downtime in minutes.
- [uptimepercent] - your minecraft servers uptime percentage (%).
- [downtimepercent] - your minecraft servers downtime percentage (%).
- [mostactivename] - your most active players IGN (in game name/username).
- [mostactivetime] - the time played in minutes of your most active player.
