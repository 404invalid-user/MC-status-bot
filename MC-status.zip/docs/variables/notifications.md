# variables for notifications

### place these in the text section on your dashboard where you would like the value to show up

- [status] - your minecraft servers current status (online/offline).
- [ip] - your minecraft servers ip.
